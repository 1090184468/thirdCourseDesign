function exit(){
	
	$.removeCookie("username");
	$.removeCookie("TOKEN");
	window.location.href="login.html"
}